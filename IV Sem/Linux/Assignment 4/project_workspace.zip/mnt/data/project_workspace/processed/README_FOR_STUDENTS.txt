Use this folder to store processed outputs and combined files for your deliverable.
